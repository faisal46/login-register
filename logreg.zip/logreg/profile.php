<?php
include_once 'lib/User.php';
include 'inc/header.php';
Session::checkSession();
?>
<?php
if (isset($_GET['id'])) {
    $userId = (int) $_GET['id'];
}
$user = new User();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
$updateUsr = $user->updateUserData($userId, $_POST);
}
    ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2>Profile <span class="pull-right"><a class="btn btn-primary" href="index.php">Back</a></h2>
        </div>
    </div>
    <div class="panel panel-body" id="content_text">
        <div class="form_align">
            <?php
            if (isset($updateUsr)) {
                echo $updateUsr;
            }
            ?>
            <?php
            $userdata = $user->getuserById($userId);
            if ($userdata) {
                ?>
                <form class="form_style" action="" method="POST">
                    <div class="form-group">
                        <label for="name">Your Nane</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo $userdata->name; ?>">
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo $userdata->username; ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $userdata->email; ?>">
                    </div>	
                    <?php
                    $sesId = Session::get("id");
                    if ($userId == $sesId) {
                        ?>
                        <button type="submit" class="btn btn-success" name="update">Update</button>
                        <a class="btn btn-info" href="cpass.php?id=<?php echo $userId; ?>">Password Change</a>
                    <?php }
                    ?>
                </form>
                <?php
            }
            
            ?>
        </div>
    </div>
    <?php include 'inc/footer.php';?>