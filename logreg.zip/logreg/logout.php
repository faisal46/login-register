<?php include 'inc/header.php';
?>
    <div class="panel panel-default">
	<div class="panel-heading">
		<h2>User Log Out</h2>
	</div>
	</div>
	<div class="panel panel-body" id="content_text">
	<div class="form_align">
		<form class="form_style" action="login.php" method="POST">
			  <div class="form-group">
				<label for="email">Email Address</label>
				<input type="email" class="form-control" id="email" name="email" required="">
			  </div>
			  <div class="form-group">
				<label for="pwd">Password</label>
				<input type="password" class="form-control" id="password" name="password" required="">
			  </div>
			  <button type="submit" class="btn btn-success" name="login">Login</button>
        </form>
    </div>
	</div>
		<?php include 'inc/footer.php';?>