<?php 
include 'inc/header.php'; 
include 'lib/User.php'; 
Session::checkLogin();
?>
<?php
    $user = new User();
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])){
        $usrRegi = $user->userRegistration($_POST);
    }
?>
<div class="panel panel-default">
    <div class="panel-heading">
        <h2>User Registration</h2>
    </div>
</div>
<div class="panel panel-body" id="content_text">
    <?php
    if (isset($usrRegi)) {
        echo $usrRegi;
        
    }
    ?>
    <div class="form_align">
        <form class="form_style" action="" method="POST">
            <div class="form-group">
                <label for="name">Your Nane</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn btn-success" name="register">Submit</button>
        </form>
    </div>
</div>
<?php include 'inc/footer.php'; ?>