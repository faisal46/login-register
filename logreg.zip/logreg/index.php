<?php
include 'inc/header.php';
include_once 'lib/User.php';
Session::checkSession();
?>
<?php
$loginmsg = Session::get("loginmsg");
if (isset($loginmsg)) {
    echo $loginmsg;
}
Session::set("loginmsg", null);
?>

<div class="panel panel-default">
    <div class="panel-heading">
        <h2>User List <span class="pull-right">Welcome! <strong> 
                    <?php
                    $name = Session::get("name");
                    if (isset($name)) {
                        echo $name;
                    }
                    ?>
                </strong> </span></h2>
    </div>
</div>
<div class="panel panel-body" id="content_text">
    <table class="table table-striped">
        <th width="20%">Serial</th>
        <th width="20%">Name</th>
        <th width="20%">Username</th>
        <th width="20%">Email Address</th>
        <th width="20%">Action</th>
        <?php
        $user = new User();
        $userdata = $user->getuserData();
        if ($userdata){
            $i = 0;
           foreach ($userdata as $usdata) {
            $i++;  
       
       
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $usdata['name']; ?></td>
                <td><?php echo $usdata['username']; ?></td>
                <td><?php echo $usdata['email']; ?></td>
                <td><a class="btn btn-primary" role="button" href="profile.php?id=<?php echo $usdata['id']; ?>">View</a></td>
            </tr>
<?php  } }else{
    ?>
        <h2>User Data Not Found</h2>
        <?php
} ?>
    </table>
</div>
<?php include 'inc/footer.php'; ?>