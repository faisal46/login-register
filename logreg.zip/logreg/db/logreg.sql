-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2018 at 10:39 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `logreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(235) NOT NULL,
  `username` varchar(235) NOT NULL,
  `email` varchar(235) NOT NULL,
  `password` varchar(235) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Faisal', 'faisalamir', 'faisalamirmostafa@gmail.com', '0977df97a9c6f524f0853c8a0d6f99c7'),
(2, 'Sahid Alam', 'SahidAlam', 'frofiq@gmail.com', '63bc47f7fa27f0282733c7578327cb0a'),
(3, 'Md. Arif Hossain', 'ArifHossain46', 'arif3327@gmail.com', '48636350cff648a56477838879da693b'),
(4, 'Sofiq', 'sofiq3327', 'sofiq3327@gmail.com', '5f38d70efacc1f59f5bc47f1faa79e92'),
(5, 'faisal', 'fffff', 'faisal145@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(6, 'Sojib Khan', 'sojib46', 'sojib46@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(7, 'Faruk lll', 'Faruk Ahmed', 'farukahmed@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(8, 'admin', 'admin', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
