<?php
include_once 'lib/User.php';
include 'inc/header.php';
Session::checkSession();
?>
<?php
if (isset($_GET['id'])) {
    $userId = (int) $_GET['id'];    
}
$user = new User();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updatepass'])) {
    $updatepass = $user->updatepass($userId, $_POST);
}
?>
<div class="panel panel-default">
    <div class="panel-heading">
        <h2>Change Password<span class="pull-right"><a class="btn btn-primary" href="profile.php?id=<?php echo $userId; ?>">Back</a></h2>
    </div>
</div>
<div class="panel panel-body" id="content_text">
    <div class="form_align">

        <?php
        if (isset($updatepass)) {
            echo $updatepass;
        }
        ?>
        <form class="form_style" action="" method="POST">
            <div class="form-group">
                <label for="old_pass">Old Password</label>
                <input type="password" class="form-control" id="old_pass" name="old_pass" value="">
            </div>
            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" class="form-control" id="password" name="password" value="">
            </div>                	              
            <button type="submit" class="btn btn-success" name="updatepass">Update</button>
        </form>
    </div>
</div>
<?php include 'inc/footer.php'; ?>